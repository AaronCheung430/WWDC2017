/*:
# Chatting with robot🤖!
WWDC 2017 Playground - by Aaron Cheung
*/
//: ## [Next Playground](@next)
import UIKit
import PlaygroundSupport
import AVFoundation
/*:
---
### Create Class
*/
class answer: UIViewController, UITextFieldDelegate {
/*:
---
### Create the Label, TextField and Button
*/
    var label: UILabel!
    var myTextField: UITextField!
    var btn: UIButton!
    var btn2: UIButton!
    var btn3: UIButton!
    var btn4: UIButton!
    var btn5: UIButton!
    var btn6: UIButton!
    var btn7: UIButton!
    var btn8: UIButton!
    var btnend: UIButton!
    var charsLeftLabel: UILabel!
    var restart: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
/*:
---
### Play backgorund music
*/
        playBackgroundMusic(filename: "Saddest Beach.mp3")
/*:
---
### Modify the View
*/
        view.frame = CGRect(x: 0.0, y: 0.0, width: 375.0, height: 670.0)
        view.backgroundColor = UIColor.white
/*:
---
### Modify Label, TextField and Button
*/
        label = UILabel(frame: CGRect(x: 0, y: 0, width: 365, height: 100))
        label.center = view.center
        label.center.y -= 170
        label.textAlignment = .center
        label.text = "What is your name?"
        label.textColor = UIColor.red
        label.font = UIFont(name: "Futura Neue", size: 20)
        label.font = label.font.withSize(30)
        self.view.addSubview(label)
        
        charsLeftLabel = UILabel(frame: CGRect(x: 0, y: 0, width: 50, height: 50))
        charsLeftLabel.center = view.center
        charsLeftLabel.center.y -= 50
        charsLeftLabel.textAlignment = .center
        charsLeftLabel.text = "15"
        charsLeftLabel.textColor = UIColor.red
        charsLeftLabel.font = UIFont(name: "Futura Neue", size: 20)
        charsLeftLabel.font = label.font.withSize(15)
        self.view.addSubview(charsLeftLabel)
        
        myTextField = UITextField(frame: CGRect(x: 0, y: 0, width: 300, height: 50))
        myTextField.placeholder = "Enter Here"
        myTextField.borderStyle = .roundedRect
        myTextField.textAlignment = .center
        myTextField.clearButtonMode = .whileEditing
        myTextField.center = view.center
        myTextField.returnKeyType = .done
        myTextField.textColor = UIColor.white
        myTextField.backgroundColor = UIColor.lightGray
        myTextField.delegate = self
        myTextField.addTarget(self, action: "textFieldDidChange:", for: UIControlEvents.editingChanged)
        self.view.addSubview(myTextField)
        
        btn = UIButton(frame: CGRect(x: 0, y: 0, width: 100, height: 50))
        btn.center = view.center
        btn.center.y += 170
        btn.setTitle("Submit",for: .normal)
        btn.setTitleColor(UIColor.red, for: UIControlState.normal)
        btn.titleLabel?.font = UIFont.boldSystemFont(ofSize: 20)
        btn.addTarget(self, action: "buttonAction:", for: UIControlEvents.touchUpInside)
        self.view.addSubview(btn)
        
        btn2 = UIButton(frame: CGRect(x: 0, y: 0, width: 100, height: 50))
        btn2.center = view.center
        btn2.setTitle("Yes",for: .normal)
        btn2.setTitleColor(UIColor.red, for: UIControlState.normal)
        btn2.titleLabel?.font = UIFont.boldSystemFont(ofSize: 20)
        btn2.addTarget(self, action: "buttonAction2:", for: UIControlEvents.touchUpInside)
        
        btn3 = UIButton(frame: CGRect(x: 0, y: 0, width: 100, height: 50))
        btn3.center = view.center
        btn3.center.y += 100
        btn3.setTitle("No",for: .normal)
        btn3.setTitleColor(UIColor.red, for: UIControlState.normal)
        btn3.titleLabel?.font = UIFont.boldSystemFont(ofSize: 20)
        btn3.addTarget(self, action: "buttonAction3:", for: UIControlEvents.touchUpInside)
        
        btn4 = UIButton(frame: CGRect(x: 0, y: 0, width: 100, height: 50))
        btn4.center = view.center
        btn4.setTitle("Yes",for: .normal)
        btn4.setTitleColor(UIColor.red, for: UIControlState.normal)
        btn4.titleLabel?.font = UIFont.boldSystemFont(ofSize: 20)
        btn4.addTarget(self, action: "buttonActionwwdc:", for: UIControlEvents.touchUpInside)

        btn5 = UIButton(frame: CGRect(x: 0, y: 0, width: 100, height: 50))
        btn5.center = view.center
        btn5.center.y += 100
        btn5.setTitle("No",for: .normal)
        btn5.setTitleColor(UIColor.red, for: UIControlState.normal)
        btn5.titleLabel?.font = UIFont.boldSystemFont(ofSize: 20)
        btn5.addTarget(self, action: "buttonActionwwdc:", for: UIControlEvents.touchUpInside)
        
        btn6 = UIButton(frame: CGRect(x: 0, y: 0, width: 100, height: 50))
        btn6.center = view.center
        btn6.center.y += 100
        btn6.center.x -= 100
        btn6.setTitle("350",for: .normal)
        btn6.setTitleColor(UIColor.red, for: UIControlState.normal)
        btn6.titleLabel?.font = UIFont.boldSystemFont(ofSize: 20)
        btn6.addTarget(self, action: "buttonAction350:", for: UIControlEvents.touchUpInside)
//        self.view.addSubview(btn6)
        
        btn7 = UIButton(frame: CGRect(x: 0, y: 0, width: 100, height: 50))
        btn7.center = view.center
        btn7.center.y += 100
        btn7.center.x += 100
        btn7.setTitle("300",for: .normal)
        btn7.setTitleColor(UIColor.red, for: UIControlState.normal)
        btn7.titleLabel?.font = UIFont.boldSystemFont(ofSize: 20)
        btn7.addTarget(self, action: "buttonAction300:", for: UIControlEvents.touchUpInside)
        
        btn8 = UIButton(frame: CGRect(x: 0, y: 0, width: 100, height: 50))
        btn8.center = view.center
        btn8.center.y += 170
        btn8.setTitle("Submit",for: .normal)
        btn8.setTitleColor(UIColor.red, for: UIControlState.normal)
        btn8.titleLabel?.font = UIFont.boldSystemFont(ofSize: 20)
        btn8.addTarget(self, action: "buttonActionsub:", for: UIControlEvents.touchUpInside)
        
        btnend = UIButton(frame: CGRect(x: 0, y: 0, width: 100, height: 50))
        btnend.center = view.center
        btnend.center.y += 170
        btnend.setTitle("Next",for: .normal)
        btnend.setTitleColor(UIColor.red, for: UIControlState.normal)
        btnend.titleLabel?.font = UIFont.boldSystemFont(ofSize: 20)
        btnend.addTarget(self, action: "buttonActionend:", for: UIControlEvents.touchUpInside)
    }
/*:
---
### Create function for button
*/
    func buttonAction(_: UIButton) {
        
        label.text = "Hi " + myTextField.text! + " !"
        myTextField.text = ""
        btn.removeFromSuperview()
        myTextField.removeFromSuperview()
        charsLeftLabel.removeFromSuperview()
        
        let delayInSeconds1 = 3.0
        DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + delayInSeconds1) {
            self.label.text = "Do you want to go to 🍎WWDC this year?"
            self.label.font = self.label.font.withSize(18)
        }
        
        let delayInSeconds = 6.0
        DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + delayInSeconds) {
            self.view.addSubview(self.btn2)
            self.view.addSubview(self.btn3)
        }
    }

    func buttonAction2(_: UIButton) {
        
        self.label.font = self.label.font.withSize(30)
        label.text = "Cool 😎"
        btn2.removeFromSuperview()
        btn3.removeFromSuperview()

        let delayInSeconds1 = 3.0
        DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + delayInSeconds1) {
            self.label.font = self.label.font.withSize(25)
            self.label.text = "Are you excited 🤗 about it?"
        }
    
        let delayInSeconds = 5.0
        DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + delayInSeconds) {
            self.view.addSubview(self.btn4)
            self.view.addSubview(self.btn5)
        }
    }
    
    func buttonAction3(_: UIButton) {
        
        self.label.font = self.label.font.withSize(30)
        label.text = "So Sad 😞"
        btn2.removeFromSuperview()
        btn3.removeFromSuperview()
        
        let delayInSeconds1 = 3.0
        DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + delayInSeconds1) {
            self.label.text = "How many people got WWDC Scholarship last year?"
            self.label.font = self.label.font.withSize(15)
        }
        
         let delayInSeconds = 5.0
        DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + delayInSeconds) {
            self.view.addSubview(self.btn6)
            self.view.addSubview(self.btn7)
        }
    }
    
    func buttonActionwwdc(_: UIButton) {
        
        self.label.font = self.label.font.withSize(25)
        label.text = "Apple Park is worth to visit!"
        btn4.removeFromSuperview()
        btn5.removeFromSuperview()
        
        let delayInSeconds1 = 3.0
        DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + delayInSeconds1) {
            self.label.text = "How many people got WWDC Scholarship last year?"
            self.label.font = self.label.font.withSize(15)
        }
        
        let delayInSeconds = 5.0
        DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + delayInSeconds) {
            self.view.addSubview(self.btn6)
            self.view.addSubview(self.btn7)
        }
    }
    
    func buttonAction350(_: UIButton) {
        
        self.label.font = self.label.font.withSize(50)
        label.text = "😯"
        btn6.removeFromSuperview()
        btn7.removeFromSuperview()
        
        let delayInSeconds1 = 3.0
        DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + delayInSeconds1) {
            self.label.font = self.label.font.withSize(30)
            self.label.text = "You know a lot of things!!!"
        }
        
        let delayInSeconds = 6.0
        DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + delayInSeconds) {
            self.label.font = self.label.font.withSize(25)
            self.label.text = "I do not have a name, either."
        }
        
        let delayInSecond = 8.0
        DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + delayInSecond) {
            self.label.text = "Can you name me?"
            self.view.addSubview(self.myTextField)
            self.charsLeftLabel.text = "15"
            self.charsLeftLabel.textColor = UIColor.black
            self.view.addSubview(self.charsLeftLabel)
        }
        
        let delayInSecond2 = 11.0
        DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + delayInSecond2) {
            self.view.addSubview(self.btn8)
        }
    }
    
    func buttonAction300(_: UIButton) {

        self.label.font = self.label.font.withSize(50)
        self.label.text = "😖"
        btn6.removeFromSuperview()
        btn7.removeFromSuperview()
        
        let delayInSeconds1 = 3.0
        DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + delayInSeconds1) {
            self.label.font = self.label.font.withSize(30)
            self.label.text = "The answer is 350!!!"
        }
        
        let delayInSeconds = 6.0
        DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + delayInSeconds) {
            self.label.font = self.label.font.withSize(25)
            self.label.text = "I do not have a name, either."
        }
        
        let delayInSecond = 8.0
        DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + delayInSecond) {
            self.label.text = "Can you name me?"
            self.view.addSubview(self.myTextField)
            self.charsLeftLabel.text = "15"
            self.charsLeftLabel.textColor = UIColor.black
            self.view.addSubview(self.charsLeftLabel)
        }
        
        let delayInSecond2 = 11.0
        DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + delayInSecond2) {
            self.view.addSubview(self.btn8)
        }
    }
    
    func buttonActionsub(_: UIButton){
        
        self.label.font = self.label.font.withSize(20)
        label.text = myTextField.text! + ", it is a nice name!☺️"
        charsLeftLabel.removeFromSuperview()
        myTextField.text = ""
        myTextField.removeFromSuperview()
        btn8.removeFromSuperview()
        
        let delayInSeconds1 = 3.0
        DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + delayInSeconds1) {
            self.label.font = self.label.font.withSize(25)
            self.label.text = "Thanks for naming me!!!"
        }
        
        let delayInSeconds = 6.0
        DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + delayInSeconds) {
            self.view.addSubview(self.btnend)
        }
    }
    
    func buttonActionend(_: UIButton) {
        btnend.removeFromSuperview()
        self.label.font = self.label.font.withSize(23)
        label.text = "↖︎↖︎↖︎Press 'Next Playground'"

    }
/*:
---
### Create function for TextField
*/
    func checkRemainingChars() {
        let allowedChars = 15
        let charsInTextView = -myTextField.text!.characters.count
        let remainingChars = allowedChars + charsInTextView
        if remainingChars <= allowedChars {
            charsLeftLabel.textColor = UIColor.black
        }
        if remainingChars <= 10 {
            charsLeftLabel.textColor = UIColor.orange
        }
        if remainingChars <= 5 {
            charsLeftLabel.textColor = UIColor.red
        }
        charsLeftLabel.text = String(remainingChars)
    }
    
    func textFieldDidChange(_ myTextField: UITextField) {
        checkRemainingChars()
    }
    
    func textField(_ myTextField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        guard let text = myTextField.text else { return true }
        let newLength = text.characters.count + string.characters.count - range.length
        return newLength <= 15 // Bool
    }
/*:
---
### Create function for background music
*/
    var backgroundMusicPlayer = AVAudioPlayer()
    func playBackgroundMusic(filename: String) {
        let url = Bundle.main.url(forResource: filename, withExtension: nil)
        guard let newURL = url else {
            print("Could not find file: \(filename)")
            return
        }
        do {
            backgroundMusicPlayer = try AVAudioPlayer(contentsOf: newURL)
            backgroundMusicPlayer.numberOfLoops = -1
            backgroundMusicPlayer.prepareToPlay()
            backgroundMusicPlayer.play()
        } catch let error as NSError {
            print(error.description)
        }
    }
}
PlaygroundPage.current.liveView = answer()
//: ### [Previous](@previous)
//: ## [Next](@next)
