/*:
# Hello playground!
 
WWDC 2017 Playground - by Aaron Cheung */
//: ## [Next Playground](@next)
import UIKit
import PlaygroundSupport
import AVFoundation
/*:
---
### Create Class
*/
class view:UIViewController{
/*:
---
### Create the ImageView, Label, Circle, Rectangle and Button
*/
    var label: UILabel!
    var label1: UILabel!
    var label2: UILabel!
    var btn2: UIButton!
    var btn: UIButton!
    var circle: UIView!
    var imageView: UIImageView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
/*:
---
### Play backgorund music
*/
        playBackgroundMusic(filename: "Sunday.mp3")
/*:
---
### Modify the View
*/
        view.frame = CGRect(x: 0.0, y: 0.0, width: 380.0, height: 670.0)
        view.backgroundColor = UIColor.white
/*:
---
### Modify the ImageView, Label, Circle, Rectangle and Button
*/
        imageView = UIImageView(frame: CGRect(x: 0, y: 0, width: 270, height: 143))
        imageView.center = view.center
        imageView.image = UIImage(named: "wwdc2017.jpg")
        imageView.center.y -= 260

        circle = UIView(frame: CGRect(x: 0.0, y: 0.0, width: 50, height: 50))
        circle.center = view.center
        circle.layer.cornerRadius = 25.0
        circle.backgroundColor = UIColor.white
        self.view.addSubview(circle)

        let rectangle = UIView(frame: CGRect(x: 0.0, y: 0.0, width: 50.0, height: 50.0))
        rectangle.center = view.center
        rectangle.layer.cornerRadius = 5.0
        rectangle.backgroundColor = UIColor.white
        self.view.addSubview(rectangle)

        label = UILabel(frame: CGRect(x: 0, y: 0, width: 300, height: 100))
        label.center = view.center
        label.center.y -= 170
        label.textAlignment = .center
        label.text = "Hello World!"
        label.textColor = UIColor.red
        label.font = UIFont(name: "Futura Neue", size: 20)
        label.font = label.font.withSize(30)
        self.view.addSubview(label)
        
        label1 = UILabel(frame: CGRect(x: 0, y: 0, width: 300, height: 100))
        label1.center = view.center
        label1.center.y -= 260
        label1.textAlignment = .center
        label1.text = "Hello World!"
        label1.textColor = UIColor.red
        label1.font = UIFont(name: "Futura Neue", size: 20)
        label1.font = label.font.withSize(15)
        
        label2 = UILabel(frame: CGRect(x: 0, y: 0, width: 300, height: 100))
        label2.center = view.center
        label2.center.y -= 220
        label2.textAlignment = .center
        label2.text = "Welcome to"
        label2.textColor = UIColor.red
        label2.font = UIFont(name: "Futura Neue", size: 20)
        label2.font = label.font.withSize(20)
        
        btn = UIButton(frame: CGRect(x: 0, y: 0, width: 200, height: 50))
        btn.center = view.center
        btn.center.y += 170
        btn.setTitle("Show more...",for: .normal)
        btn.setTitleColor(UIColor.black, for: .normal)
        btn.addTarget(self, action: "buttonAction:", for: UIControlEvents.touchUpInside)
        
        btn2 = UIButton(frame: CGRect(x: 0, y: 0, width: 200, height: 50))
        btn2.center = view.center
        btn2.center.y += 170
        btn2.setTitle("Next",for: .normal)
        btn2.setTitleColor(UIColor.black, for: .normal)
        btn2.addTarget(self, action: "buttonActionNext:", for: UIControlEvents.touchUpInside)
/*:
---
### Create animations and delay for Label, Circle and Rectangle
*/
        UIView.animate(withDuration: 4.0, delay: 0, options: [.repeat, .autoreverse], animations: {
            
            let endingColor = UIColor(red: (102.0/255.0), green: (255.0/255.0), blue: (255.0/255.0), alpha: 1.0)
            self.circle.backgroundColor = endingColor
            let scaleTransform = CGAffineTransform(scaleX: 5.0, y: 5.0)
            self.circle.transform = scaleTransform
            let rotationTransform = CGAffineTransform(rotationAngle: 3.14)
            rectangle.transform = rotationTransform
        }, completion: nil)
        
        let delayInSeconds = 4.0
        DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + delayInSeconds) {
            self.label.text = "Welcome to"
            }
        
        let delayInSeconds1 = 6.0
        DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + delayInSeconds1) {
            self.label.text = "WWDC 2017"
            self.view.addSubview(self.btn)
            self.view.addSubview(self.imageView)
        }
    }
/*:
---
### Create function for button
*/
    func buttonAction(_: UIButton) {
        self.view.addSubview(label1)
        self.view.addSubview(label2)
        btn.removeFromSuperview()
        imageView.removeFromSuperview()
        self.circle.backgroundColor = UIColor.green

        let delayInSeconds1 = 3.0
        DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + delayInSeconds1) {
            self.view.addSubview(self.btn2)
        }
    }
    
    func buttonActionNext(_: UIButton) {
        label1.removeFromSuperview()
        label2.removeFromSuperview()
        btn2.removeFromSuperview()
        label.font = label.font.withSize(23)
        label.text = "↖︎↖︎↖︎Press 'Next Playground'"
        self.circle.backgroundColor = UIColor.purple
    }
/*:
---
### Create function for background music
*/
    var backgroundMusicPlayer = AVAudioPlayer()
    func playBackgroundMusic(filename: String) {
        let url = Bundle.main.url(forResource: filename, withExtension: nil)
        guard let newURL = url else {
            print("Could not find file: \(filename)")
            return
        }; do {
            backgroundMusicPlayer = try AVAudioPlayer(contentsOf: newURL)
            backgroundMusicPlayer.numberOfLoops = -1
            backgroundMusicPlayer.prepareToPlay()
            backgroundMusicPlayer.play()
        } catch let error as NSError {
            print(error.description)
        }
    }
}
PlaygroundPage.current.liveView = view()


//: ## [Next](@next)
