/*:
# 3D Box
WWDC 2017 Playground - by Aaron Cheung
*/
//: ## Please wait for a while for loading!
import SceneKit
import PlaygroundSupport
import UIKit
import AVFoundation
/*:
---
### Create Class
*/
class answer: UIViewController{
/*:
---
### Create the Label, SCNBox, SCNScene, SegmentedControl and Button
*/
    var colorpicker: UISegmentedControl!
    var btn: UIButton!
    var label: UILabel!
    var label1: UILabel!
    var box = SCNBox()
    let scene = SCNScene()

    override func viewDidLoad() {
        super.viewDidLoad()
/*:
---
### Modify the View
*/
        view.frame = CGRect(x: 0.0, y: 0.0, width: 380.0, height: 670.0)
        view.backgroundColor = UIColor.white
/*:
---
### Modify the SCNView
*/
        let view3d = SCNView(frame: CGRect(x: 0, y: 0, width: 370, height: 400))
        view3d.backgroundColor = UIColor.lightGray
        view3d.scene = scene
        view3d.center = view.center
        view3d.center.y += 120
        view3d.allowsCameraControl = true
        view3d.autoenablesDefaultLighting = true
        view.addSubview(view3d)
/*:
---
### Modify Label, SegmentedControl and Button
*/
        label = UILabel(frame: CGRect(x: 0, y: 0, width: 360, height: 50))
        label.center = view.center
        label.center.y -= 250
        label.textAlignment = .center
        label.text = "Choose color first, then move the boxes with mouse!"
        label.textColor = UIColor.black
        label.font = UIFont(name: "Futura Neue", size: 20)
        label.font = label.font.withSize(15)
        view.addSubview(label)
        
        label1 = UILabel(frame: CGRect(x: 0, y: 0, width: 360, height: 50))
        label1.center = view.center
        label1.center.y -= 150
        label1.textAlignment = .center
        label1.text = "Thank You"
        label1.textColor = UIColor.green
        label1.font = UIFont(name: "Futura Neue", size: 20)
        label1.font = label.font.withSize(30)
        
        colorpicker = UISegmentedControl(items: ["Black", "Red", "Orange", "Blue", "Purple"])
        colorpicker.center = view.center
        colorpicker.addTarget(self, action: "changecolor:", for: .valueChanged)
        colorpicker.center.y -= 200
        view.addSubview(colorpicker)
/*:
---
### Modify SCNNobe, SCNCamera, SCNBox and SCNVector
*/
        let camNode = SCNNode()
        camNode.camera = SCNCamera()
        scene.rootNode.addChildNode(camNode)
        camNode.position = SCNVector3(0, 0, 15)
        box = SCNBox(width: 2.0, height: 2.0, length: 2.0, chamferRadius: 0.2)
        
        for i in 1 ... 4 {
            // This is where it takes a few seconds to run
            let cube = SCNNode(geometry: box)
            cube.position = SCNVector3(i, i, i)
            scene.rootNode.addChildNode(cube)
            box.firstMaterial?.diffuse.contents = UIColor.green
        }
/*:
---
### Play backgorund music
*/
        playBackgroundMusic(filename: "South Town.mp3")
/*:
---
### Create delay for Label
*/
        let delayInSeconds = 8.0
        DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + delayInSeconds) {
            self.view.addSubview(self.label1)
        }
    }
/*:
---
### Create function for SegmentedControl
*/
    func changecolor(_ sender: UISegmentedControl) {
        
        switch colorpicker.selectedSegmentIndex {
        case 0:
            colorpicker.tintColor = UIColor.black
            box.firstMaterial?.diffuse.contents = UIColor.black
            label1.textColor = UIColor.black
        case 1:
            colorpicker.tintColor = UIColor.red
            box.firstMaterial?.diffuse.contents = UIColor.red
            label1.textColor = UIColor.red
        case 2:
            colorpicker.tintColor = UIColor.orange
            box.firstMaterial?.diffuse.contents = UIColor.orange
            label1.textColor = UIColor.orange
        case 3:
            colorpicker.tintColor = UIColor.blue
            box.firstMaterial?.diffuse.contents = UIColor.blue
            label1.textColor = UIColor.blue
        case 4:
            colorpicker.tintColor = UIColor.purple
            box.firstMaterial?.diffuse.contents = UIColor.purple
            label1.textColor = UIColor.purple
        default:
            break
        }
    }
/*:
---
### Create function for background music
*/
    var backgroundMusicPlayer = AVAudioPlayer()
    func playBackgroundMusic(filename: String) {
        let url = Bundle.main.url(forResource: filename, withExtension: nil)
        guard let newURL = url else {
            print("Could not find file: \(filename)")
            return
        }; do {
            backgroundMusicPlayer = try AVAudioPlayer(contentsOf: newURL)
            backgroundMusicPlayer.numberOfLoops = -1
            backgroundMusicPlayer.prepareToPlay()
            backgroundMusicPlayer.play()
        } catch let error as NSError {
            print(error.description)
        }
    }
}

PlaygroundPage.current.liveView = answer()
//: ### [Previous](@previous)
//: ## [Next](@next)
